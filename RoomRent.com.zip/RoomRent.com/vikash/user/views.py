from django.shortcuts import render,redirect
from django.conf import settings
from myadmin import models as myadmin_models

media_url=settings.MEDIA_URL
# from django.http import HttpResponse

#middile to check session for user routes..
def sessioncheckuser_middleware(get_response):
    def middleware(request):
        if request.path=='/user/':
            if request.session['sunm']==None or request.session['srole']!="user":
                response = redirect('/login/')
            else:
                response = get_response(request)
        else:
            response = get_response(request)
        return response
    return middleware     

# Create your views here.
def userhome(request):
    # return HttpResponse("<h1>User panel<h1>")
    return render(request,"userhome.html",{"sunm":request.session["sunm"]})

def searchcat(request):
    clist=myadmin_models.Category.objects.all()
    return render(request,"searchcat.html",{"sunm":request.session["sunm"],"clist":clist,"media_url":media_url})

def searchsubcat(request):
    catname=request.GET.get("catname")
    clist=myadmin_models.Category.objects.all()
    sclist=myadmin_models.SubCategory.objects.filter(catname=catname)
    return render(request,"searchsubcat.html",{"sunm":request.session["sunm"],"catname":catname,"sclist":sclist,"media_url":media_url,"clist":clist})

def addproperty(request):
    return render(request,"addproperty.html",{"sunm":request.session["sunm"]})

  

