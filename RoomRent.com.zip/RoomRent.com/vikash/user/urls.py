
from django.urls import path

from . import views

urlpatterns = [
    path('',views.userhome),
    path('searchcat/',views.searchcat),
    path('searchsubcat/',views.searchsubcat),
    path('addproperty/',views.addproperty)
]
