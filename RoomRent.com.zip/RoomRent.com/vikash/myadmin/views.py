# from http.client import HTTPResponse
# from xml.dom import registerDOMImplementation
# from pyexpat import model
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage

from .import models

from vikash import models as vikash_models

#middileware to check session for admin routes..

def sessioncheckmyadmin_middleware(get_response):
    def middleware(request):
        if request.path=='/myadmin/' or request.path=='/myadmin/manageusers/' or request.path=='/myadmin/manageuserstatus/' or request.path=='/myadmin/addcategory/':
            if request.session['sunm']==None or request.session['srole']!="admin":
                response = redirect('/login/')
            else:
                response = get_response(request)
        else:
            response = get_response(request)
        return response
    return middleware        


# Create your views here.
def adminhome(request):     
    return render(request,"adminhome.html",{"sunm":request.session["sunm"]})

def manageusers(request):
    userDetails=vikash_models.ragister.objects.filter(role="user")
    # print(userDetails)
    return render(request,"manageusers.html",{"userDetails":userDetails,"sunm":request.session["sunm"]})

def manageuserstatus(request):
    regid=int(request.GET.get("regid"))
    status=request.GET.get("s")
    # print(regid,"-----",status)   
    if status=="block":
        vikash_models.ragister.objects.filter(regid=regid).update(status=0)
    elif status=="verify":
        vikash_models.ragister.objects.filter(regid=regid).update(status=1)
    else:
        vikash_models.ragister.objects.filter(regid=regid).delete()
    return redirect("/myadmin/manageusers/")    

def addcategory(request):
    if request.method=="GET":
        return render(request,"addcategory.html",{"sunm":request.session["sunm"],"output":""})
    else:
        catname=request.POST.get("catname")
        caticon=request.FILES["caticon"]
        fs=FileSystemStorage()
        filename = fs.save(caticon.name,caticon)
        p=models.Category(catname=catname,caticonname=filename)
        p.save()
        return render(request,"addcategory.html",{"sunm":request.session["sunm"],"output":"Category Added Successfully"})

def addsubcategory(request):
    clist=models.Category.objects.all()
    print(clist)
    if request.method=="GET":
        return render(request,"addsubcategory.html",{"sunm":request.session["sunm"],"clist":clist,"output":""})
    else:
        catname=request.POST.get("catname")
        subcatname=request.POST.get("subcatname")
        caticon=request.FILES["caticon"]
        fs=FileSystemStorage()
        filename = fs.save(caticon.name,caticon)
        p=models.SubCategory(catname=catname,subcatname=subcatname,subcaticonname=filename)
        p.save()
        return render(request,"addsubcategory.html",{"sunm":request.session["sunm"],"clist":clist,"output":"SubCategory Added Successfully"})


def cpadmin(request):     
    if request.method=="GET":
        return render(request,"cpadmin.html",{"output":"","sunm":request.session["sunm"]})
    else:
        opass=request.POST.get("opass")
        npass=request.POST.get("npass")
        cnpass=request.POST.get("cnpass")
        sunm=request.session["sunm"]
        userDetails=vikash_models.ragister.objects.filter(username=sunm,password=opass)

        if len(userDetails)>0:
            if npass==cnpass:
                vikash_models.ragister.objects.filter(username=sunm).update(password=cnpass)
                msg="Password changed successfully, please login again..."
            else:
                msg="New & confirm New password mismatch"
        else:
            msg="Invalid Old Password"

        return render(request,"cpadmin.html",{"output":msg,"sunm":sunm})



def epadmin(request):
    if request.method=="GET":
        userDetails=vikash_models.ragister.objects.filter(username=request.session["sunm"])
        m,f="",""
        if userDetails[0].gender=="male":
            m="checked"
        else:
            f="checked"
        return render(request,"epadmin.html",{"userDetails":userDetails[0],"m":m,"f":f,"sunm":request.session["sunm"]})
    else:
        name=request.POST.get("name")
        username=request.POST.get("username")   
        mobile=request.POST.get("mobile")
        address=request.POST.get("address")
        city=request.POST.get("city")
        gender=request.POST.get("gender") 
        vikash_models.ragister.objects.filter(username=username).update(name=name,mobile=mobile,address=address,city=city,gender=gender)
        return redirect("/myadmin/epadmin/") 

        


        

    

