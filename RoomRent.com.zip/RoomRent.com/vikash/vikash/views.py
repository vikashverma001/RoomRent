
#template page

# from distutils.log import info
from django.shortcuts import render,redirect
from django.http import HttpResponse
from .import models
import time

#Middileware to check   session for mainapp routes
def sessioncheck_middleware(get_response):
    def middleware(request):
        if request.path=='/home/' or request.path=='/about/' or request.path=='/contact/' or request.path=='/login/' or request.path=='/service/' or request.path=='/ragister/':
            request.session['sunm']=None
            request.session['srole']=None
            response = get_response(request)
        else:
            response = get_response(request)
        return response
    return middleware

# Logic is Implement in views.py And we will display in .html file

def home(request):
    return render(request,"home.html")

def about(request):
    return render(request,"about.html")

def contact(request):
    return render(request,"contact.html")

def service(request):
    return render(request,"service.html")

def ragister(request):
    if request.method=="GET":
        return render(request,"ragister.html",{"output": ""})
    else:
        # print(request.POST) 
        name=request.POST.get("name")
        username=request.POST.get("username")   
        password=request.POST.get("password")
        mobile=request.POST.get("mobile")
        address=request.POST.get("address")
        city=request.POST.get("city")
        gender=request.POST.get("gender")    
        info=time.asctime()                 

        p=models.ragister(name=name,username=username,password=password,mobile=mobile,address=address,city=city,gender=gender,status=0,role="user",info=info)
        p.save()
        # print(gender)
        return render(request,"ragister.html",{"output":"User Registered Successfully"})

     

def login(request):
    cunm,cpass="",""
    if request.COOKIES.get("cunm")!=None:
        cunm=request.COOKIES.get("cunm")
        cpass=request.COOKIES.get("cpass")  

    if request.method=="GET":
        return render(request,"login.html",{"output":"","cunm":cunm,"cpass":cpass})
    else:
        username=request.POST.get("username")
        password=request.POST.get("password")

        userDetails=models.ragister.objects.filter(username=username,password=password,status=1)

        if len(userDetails)==0:
            return render(request,"login.html",{"output":"Invalid User Name or verify your account...","cunm":cunm,"cpass":cpass})
        else:
            #to store user details in session
            request.session["sunm"]=userDetails[0].username
            request.session["srole"]=userDetails[0].role

            if userDetails[0].role=="admin":
                response=redirect("/myadmin/")
            else:
                response=redirect("/user/")

            # to store user details in cookies
            chk=request.POST.get("chk")
            if(chk!=None):
                response.set_cookie("cunm",userDetails[0].username,max_age=3600*24*365)
                response.set_cookie("cpass",userDetails[0].password,max_age=3600*24*365)
            return response
    



